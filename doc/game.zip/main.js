/**
 *
 * @param topX The top x coordinate.
 * @param topY The top y coordinate.
 * @constructor
 */
function GameDisplay(tX,tY,map){

    var mapImg=map;
    var topX=tX;
    var topY=tY;
    var canvas=document.getElementById("game");
    var g=canvas.getContext("2d");
    var inputListeners=new Inputs(canvas);
    var dataCon=new DataConnection();



    this.setupGame=function(){
    }

    this.gameLoop=function(){

        g.fillStyle="#FFFFFF";
        g.drawImage(mapImg,topX,topY,mapImg.width/4,mapImg.height/4);
        //g.fillRect(tX,tY,1000,800);
        var gameState=dataCon.getGameState(); //Ask for the game state
        gameState.map(function(state){

            if(state.getOwner()==1){
                g.fillStyle='#FF0000';
            }
            if(state.getOwner()==2){
                g.fillStyle='#FFFFFF';
            }
            if(state.getOwner()==3){
                g.fillStyle='#000000';
            }
            if(state.getOwner()==4){
                g.fillStyle='#663399';
            }
            if(state.getOwner()==5){
                g.fillStyle='#FFA500';
            }
            g.strokeRect(state.getX()+tX,state.getY()+tY,state.getSize(),state.getSize());
            g.font='10pt Calibri';
            g.fillText(""+state.getArmy(),state.getX()+10+tX,state.getY()+20+tY);
        });
    }
}

function ScoreDisplay(tX,tY){
    var topX=tX;
    var topY=tY;
    var canvas=document.getElementById("game");
    var g=canvas.getContext("2d");
    g.fillStyle='#000000';
    g.font='20pt Calibri';
    g.fillText("Player Scores",tX+25,tY);

    var drawX=100;
    var drawY=topY+100;
    g.font='10pt Calibri';
    g.fillText("Red: "+10,drawX,drawY);
    drawY+=100;
    g.fillText("Blue: "+10,drawX,drawY);
    drawY+=100;
    g.fillText("Green: "+10,drawX,drawY);
}

function TitleDisplay(tX,tY){
    var topX=tX;
    var topY=tY;
    var canvas=document.getElementById("game");
    var g=canvas.getContext("2d");

    var imageObj=new Image();
    imageObj.onload=function(){
        g.drawImage(this,tX+50,tY,imageObj.width/2.2,imageObj.height/2.2);
        g.font='40pt Calibri';
        g.fillStyle='#000000';
        g.fillText("Clash of Empires",tX+100,tY+50);
    }
    imageObj.src='http://gulugames.com/wp-content/uploads/2014/01/Banner1.png';



}

var score=new ScoreDisplay(0,100);
var title=new TitleDisplay(200,0);

//This is the main loop of the game
var mapImg=new Image();
mapImg.onload=function(){
    var disp=new GameDisplay(250,100,mapImg);
    disp.setupGame();
    setInterval(disp.gameLoop,30);
}

mapImg.src='images/map.png';


